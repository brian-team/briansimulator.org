# Figure paramaters
from pylab import *

def new_fig(scale=0.5):
    rc('lines',linewidth=2)
    rc('font',size=18*scale)
    rc('xtick',labelsize=18*scale)
    rc('ytick',labelsize=18*scale)
    rc('legend',fontsize=18*scale)
    rc('axes',labelsize=18*scale,titlesize=18*scale)
    fontsize=18*scale
    w,h=rcParamsDefault['figure.figsize']    
    figure(figsize=(w*scale,h*scale))

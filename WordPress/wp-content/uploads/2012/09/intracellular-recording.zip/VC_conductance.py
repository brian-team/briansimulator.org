'''
Conductance estimation in voltage clamp.

Point model with no active conductances.
The synaptic conductances are identical for all trials,
plus added noise (signal/noise = 2).
Series resistance compensation is 90% (gets bad at 50%).
'''
from brian import *
from brian.library.electrophysiology import *
from brian.library.random_processes import *
from scipy.stats import linregress
from fig_params import *

rectify=lambda x:clip(x/siemens,0,Inf)*siemens

# Clock
clock_model=Clock(dt=0.01*ms)
clock_recording=Clock(dt=0.1*ms)

# Parameters
Imin=-25*nA
Imax=25*nA
C=200*pF
El=-65*mV
Ee=0*mV
Ei=-75*mV
gl=20*nS
taue=3*ms
taui=7*ms
ge0=20*nS
gi0=50*nS
sigmae=10*nS
sigmai=20*nS
Re=10*Mohm
Ce=.1*ms/Re
duration=150*ms
N=10

# Synaptic conductances
eqs_syn=OrnsteinUhlenbeck('ge',ge0,sigmae,taue)
eqs_syn+=OrnsteinUhlenbeck('gi',gi0,sigmai,taui)
synapses=NeuronGroup(1,model=eqs_syn,clock=clock_model)

# Neuron model and amplifier
eqs=Equations('''
dvm/dt=(gl*(El-vm)+rectify(ge+ge_noise)*(Ee-vm)+rectify(gi+gi_noise)*(Ei-vm)+i_inj)/C:volt
v_cmd:volt
ge:siemens
gi:siemens
''')
eqs+=OrnsteinUhlenbeck('ge_noise',0*nS,.5*sigmae,taue) # noise
eqs+=OrnsteinUhlenbeck('gi_noise',0*nS,.5*sigmai,taui) # noise
eqs+=electrode(.2*Re,Ce)
eqs+=voltage_clamp(vm='v_el',v_cmd='v_cmd',i_inj='i_cmd',i_rec='ic',
                   Re=.8*Re,Rs=.9*Re,tau_u=.1*ms)

# Neuron
neuron=NeuronGroup(N,model=eqs,clock=clock_model)

# Injection of identical synaptic currents
@network_operation(clock=clock_recording)
def inject_syn(): # inject synaptic current
    neuron.ge=synapses.ge[0]
    neuron.gi=synapses.gi[0]

neuron.vm=El
neuron.ge=ge0
neuron.gi=gi0
neuron.v_cmd=linspace(-80*mV,-50*mV,N)

run(30*ms)

ge_mon=StateMonitor(neuron,'ge',record=0,clock=clock_recording)
gi_mon=StateMonitor(neuron,'gi',record=0,clock=clock_recording)
I_mon=StateMonitor(neuron,'ic',record=True,clock=clock_recording)

run(duration)

# Linear regression
M=len(I_mon.times)
I=zeros((N,M))
gtot=zeros(M)
Erev=zeros(M)
for i in range(N):
    I[i,:]=I_mon[i]
for j in range(M):
    slope,intercept,_,_,_=linregress(neuron.v_cmd,I[:,j])
    gtot[j]=-slope
    Erev[j]=-intercept/slope

# Decomposition
ge=(gtot*Erev-gl*El-(gtot-gl)*Ei)/(Ee-Ei)
gi=gtot-ge-gl

new_fig(scale=.5)
subplot(311)
for i in range(N):
    plot(I_mon.times/ms,I_mon[i]/nA,'k')
xticks([])
ylabel('I (nA)')
yticks([-2,0,2,4])
xlim(30,180)
subplot(312)
#plot(I_mon.times/ms,gtot/nS)
xticks([])
xlim(30,180)
yticks([0,25,50])
plot(ge_mon.times/ms,rectify(ge_mon[0])/nS,'k--')
plot(I_mon.times/ms,ge/nS,'k')
ylabel('ge (nS)')
subplot(313)
plot(gi_mon.times/ms,rectify(gi_mon[0])/nS,'k--')
plot(I_mon.times/ms,gi/nS,'k')
#plot(I_mon.times/ms,Erev/mV)
xlabel('Time ms')
ylabel('gi (nS)')
yticks([0,50,100])
xticks([50,100,150])
xlim(30,180)
show()

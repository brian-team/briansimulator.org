'''
Error in DCC as a function of (clock) frequency
for taum/tau = 100 and 200
'''
from brian import *
from brian.library.electrophysiology import *
from fig_params import *

c1=Clock(dt=.002*ms) # simulation clock
c2=Clock(dt=2*ms)   # frequency change clock

taum=10*ms        # membrane time constant
gl=1./(50*Mohm)   # leak conductance
Cm=taum*gl        # membrane capacitance
Re=50*Mohm        # electrode resistance
#Ce=0.1*ms/Re      # electrode capacitance
duration=5*second

eqs=Equations('''
dvm/dt=(-gl*vm+i_inj)/Cm : volt
I:amp # command current
Ce:farad
''')
eqs+=current_clamp(i_cmd='I',Re=Re,Ce="Ce")
setup=NeuronGroup(2,model=eqs,clock=c1)
setup.Ce=array([0.05*ms,.1*ms])/Re
ampli=DCC(setup,'v_rec','I',.5*kHz)
DCCrecording=StateMonitor(ampli,'record',record=True,clock=c2,when='start')

ampli.command=2*nA
@network_operation(clock=c2,when='end')
def change_freq(c):
    ampli.set_frequency(.1*kHz+(c.t/duration)*3*kHz)

run(duration,report='text')

n=len(DCCrecording.times)
freq=linspace(.1,.1+3,n)
new_fig(scale=0.5)
plot(freq,DCCrecording[0]/mV-100,'k')
plot(freq,DCCrecording[1]/mV-100,'k')
plot(freq,freq*0,'k--')
xlim(0.5,3)
ylim(-10,25)
xticks([.5,1,2,3])
yticks([-10,0,10,20])
xlabel('DCC frequency (kHz)')
ylabel('Error (%)')
show()

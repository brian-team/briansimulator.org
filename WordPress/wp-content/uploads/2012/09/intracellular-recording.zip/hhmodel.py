'''
Hodgkin-Huxley-like model.
Adapted from Mainen.
'''
from brian import *

# PARAMETERS
area=pi*(80*umetre)**2
C=1*uF/cm**2*area
gl=0.045*msiemens*5/cm**2*area # High conductance
El=-70*mV
ENa=60*mV
EK=-90*mV
gNa=33.6*msiemens*5/cm**2*area
gK=15.4*msiemens/cm**2*area
A_alpham=.182/(ms*mV)
A_betam=.124/(ms*mV)
A_alphah=.024/(ms*mV)
A_betah=.0091/(ms*mV)
A_alphan=0.02/(ms*mV)
A_betan=0.002/(ms*mV)
v12_alpham=-25*mV
v12_betam=-25*mV
v12_alphah=-40*mV
v12_betah=-65*mV
v12_hinf=-55*mV
v12_alphan=25*mV
v12_betan=25*mV
k_alpham=9*mV
k_betam=9*mV
k_alphah=5*mV
k_betah=5*mV
k_hinf=6.2*mV
k_alphan=9*mV
k_betan=9*mV
#q10=2.3 # ?
I0=1.5*uA/cm**2*area
sigmaI=1.5*uA/cm**2*area
tauI=10*ms

eqs_hh=Equations("""
# Membrane equation, Iing is the electrode current
dv/dt=(gl*(El-v)+gNa*m**3*h*(ENa-v)+gK*n*(EK-v)+I+Iinj)/C : volt

# Synaptic-like input
dI/dt=(I0-I)/tauI+sigmaI*(.5*tauI)**(-.5)*xi: amp

# Sodium activation
alpham=A_alpham*(v-v12_alpham)/(1-exp((v12_alpham-v)/k_alpham)) : hertz
betam=-A_betam*(v-v12_betam)/(1-exp(-(v12_betam-v)/k_betam)) : hertz
minf=alpham/(alpham+betam) : 1
taum=1/(alpham+betam) : second
dm/dt=(minf-m)/taum : 1

# Potassium activation
alphan=A_alphan*(v-v12_alphan)/(1-exp((v12_alphan-v)/k_alphan)) : hertz
betan=-A_betan*(v-v12_betan)/(1-exp(-(v12_betan-v)/k_betan)) : hertz
ninf=alphan/(alphan+betan) : 1
taun=1/(alphan+betan) : second
dn/dt=(ninf-n)/taun : 1

# Sodium inactivation
alphah=A_alphah*(v-v12_alphah)/(1-exp((v12_alphah-v)/k_alphah)) : hertz
betah=-A_betah*(v-v12_betah)/(1-exp(-(v12_betah-v)/k_betah)) : hertz
hinf=1/(1+exp((v-v12_hinf)/k_hinf)) : 1
tauh=1/(alphah+betah) : second
dh/dt=(hinf-h)/tauh : 1
""")

'''
Voltage-clamp with a step command
'''
from brian import *
from brian.library.electrophysiology import *
from fig_params import *

defaultclock.dt=.01*ms

taum=20*ms
gl=20*nS
Cm=taum*gl
Re=10*Mohm
Ce=0.2*ms/Re
N=3

eqs=Equations('''
dvm/dt=(-gl*vm+i_inj)/Cm : volt
v_cmd:volt
Rs:ohm
''')
eqs+=electrode(.2*Re,Ce)
eqs+=voltage_clamp(vm='v_el',v_cmd='v_cmd',i_inj='i_cmd',i_rec='ic',
                   Re=.8*Re,Rs='Rs',tau_u=.1*ms)
setup=NeuronGroup(N,model=eqs)
setup.v=0*mV
recording=StateMonitor(setup,'ic',record=True)
soma=StateMonitor(setup,'vm',record=True)
setup.Rs=array([0,.8,.9])*Re

run(10*ms)
setup.v_cmd=20*mV
run(30*ms)
new_fig(scale=0.5)
subplot(212)
# Current
for i in range(N):
    plot(recording.times/ms,recording[i]/nA,'k')
plot(recording.times/ms,(0*recording[0]-gl*setup.v_cmd[0])/nA,'k--') # True one
xlim(0,25)
ylim(-7,3)
xlabel('Time (ms)')
ylabel('I (nA)')
yticks([-6,-3,0,3])
subplot(211)
# Voltage
for i in range(N):
    plot(soma.times/ms,soma[i]/mV-80,'k')
xlim(0,25)
ylabel('Vm (mV)')
ylim(-85,-50)
yticks([-80,-70,-60,-50])
show()

'''
DCC example (pulse)
'''
from brian import *
from brian.library.electrophysiology import *

defaultclock.dt=0.01*ms

taum=20*ms        # membrane time constant
gl=1./(50*Mohm)   # leak conductance
Cm=taum*gl        # membrane capacitance
Re=20*Mohm        # electrode resistance
Ce=0.1*ms/Re      # electrode capacitance

eqs=Equations('''
dvm/dt=(-gl*vm+i_inj)/Cm : volt
Rbridge:ohm # bridge resistance
I:amp # command current
''')
eqs+=current_clamp(i_cmd='I',Re=Re,Ce=Ce)
setup=NeuronGroup(1,model=eqs)
ampli=DCC(setup,'v_rec','I',1*kHz)
soma=StateMonitor(setup,'vm',record=True)
recording=StateMonitor(setup,'v_rec',record=True)
DCCrecording=StateMonitor(ampli,'record',record=True,clock=Clock(dt=1*ms),when='start')

# No compensation
run(20*ms)
ampli.command=.5*nA
run(100*ms)
ampli.command=0*nA
run(60*ms)

scale=.5
rc('lines',linewidth=2)
rc('font',size=18*scale)
rc('xtick',labelsize=18*scale)
rc('ytick',labelsize=18*scale)
rc('legend',fontsize=18*scale)
rc('axes',labelsize=18*scale,titlesize=18*scale)
fontsize=18*scale
w,h=rcParamsDefault['figure.figsize']    
figure(figsize=(w,h*.5))

subplot(121)
plot(recording.times/ms,recording[0]/mV-70,'k')
plot(DCCrecording.times/ms-1,DCCrecording[0]/mV-70,'k.')
plot(soma.times/ms,soma[0]/mV-70,'k--')
ylabel('V (mV)')
xlabel('Time (ms)')
xlim(0,180)
xticks([0,60,120,180])
yticks([-70,-50,-30,10])
subplot(122)
ind1=(recording.times>=114*ms)&(recording.times<=125*ms)
ind2=(DCCrecording.times>=114*ms)&(DCCrecording.times<=125*ms)
plot(recording.times[ind1]/ms,recording[0][ind1]/mV-70,'k')
plot(DCCrecording.times[ind2]/ms-1,DCCrecording[0][ind2]/mV-70,'k.')
plot(soma.times[ind1]/ms,soma[0][ind1]/mV-70,'k--')
xlim(114,125)
xticks([115,120,125])
yticks([-50,0,-15])
xlabel('Time (ms)')
show()

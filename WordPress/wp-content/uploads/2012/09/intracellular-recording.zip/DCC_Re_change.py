'''
Effect of a change in Re (electrode resistance) in a DCC recording,
near the optimal frequency setting.

Optimal DCC setting for taum = 10 ms:
1.17 kHz if taue = .1 ms
2.17 kHz if taue = .05 ms
'''
from brian import *
from brian.library.electrophysiology import *
from fig_params import *

c1=Clock(dt=.001*ms) # simulation clock
c2=Clock(dt=2*ms)   # frequency change clock

taum=10*ms        # membrane time constant
gl=1./(50*Mohm)   # leak conductance
Cm=taum*gl        # membrane capacitance
Re0=20*Mohm        # electrode resistance
Re_max=100*Mohm
Ce=0.1*ms/(50*Mohm)      # electrode capacitance
duration=2*second

eqs=Equations('''
dvm/dt=(-gl*vm+i_inj)/Cm : volt
I:amp # command current
Re:ohm
''')
eqs+=current_clamp(i_cmd='I',Re='Re',Ce=Ce)
setup=NeuronGroup(1,model=eqs,clock=c1)
ampli=DCC(setup,'v_rec','I',1.17*kHz)
DCCrecording=StateMonitor(ampli,'record',record=True,clock=c2,when='start')
Re_rec=StateMonitor(setup,'Re',record=True,clock=c2,when='start')

setup.Re=Re0
ampli.command=2*nA
@network_operation(clock=c2,when='end')
def change_Re(c):
    setup.Re=Re0+(Re_max-Re0)*c.t/duration

run(duration,report='text')

new_fig(scale=0.5)
plot(Re_rec[0]/Mohm,DCCrecording[0]/mV,'k')
plot(Re_rec[0]/Mohm,100+0*DCCrecording[0]/mV,'k--')
xlabel('Re (M$\Omega$)')
ylabel('Error (%)')
xlim(25,100)
xticks([25,50,75,100])
yticks([90,100,110,120,130])
ylim(90,130)
show()

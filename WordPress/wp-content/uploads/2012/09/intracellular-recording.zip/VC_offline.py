'''
Offline series compensation (voltage-clamp)
'''
from brian import *
from brian.library.electrophysiology import *
from fig_params import *

defaultclock.dt=.01*ms

taum=20*ms
gl=20*nS
Cm=taum*gl
Re=10*Mohm
Ce=.1*ms/Re
taus=5*ms
Is0=.4*nA
sigma=Is0*.5
duration=200*ms

eqs=Equations('''
dvm/dt=(-gl*vm+i_inj+Is)/Cm : volt
v_cmd:volt
dIs/dt=(Is0-Is)/taus+sigma*(2/taus)**.5*xi : amp
''')
eqs+=electrode(.2*Re,Ce) # Distributed capacitance, contributes to Rs misestimation
eqs+=voltage_clamp(vm='v_el',v_cmd='v_cmd',i_inj='i_cmd',i_rec='ic',
                   Re=.8*Re,Rs=0*ohm,tau_u=.1*ms)
setup=NeuronGroup(1,model=eqs)
setup.v=0*mV
current=StateMonitor(setup,'Is',record=True)
recording=StateMonitor(setup,'ic',record=True)
soma=StateMonitor(setup,'vm',record=True)
vcmd=StateMonitor(setup,'v_cmd',record=True)

run(10*ms)
setup.v_cmd=10*mV
run(20*ms)
setup.v_cmd=0*mV
run(duration)

# Estimation of Rs from transient
# (imperfect because of distributed capacitance)
n=(10*ms)/defaultclock.dt+2
Rs=-10*mV/((recording[0][n]-recording[0][n-1])*amp)
print 'Rs=',Rs
Rm=1/gl # From current-clamp response to pulse

# Offline correction
I=recording[0]*(Rm+Rs)/Rm

print mean(current[0]/nA),mean(I/nA),mean(recording[0]/nA)

scale=.5
rc('lines',linewidth=2)
rc('font',size=18*scale)
rc('xtick',labelsize=18*scale)
rc('ytick',labelsize=18*scale)
rc('legend',fontsize=18*scale)
rc('axes',labelsize=18*scale,titlesize=18*scale)
fontsize=18*scale
w,h=rcParamsDefault['figure.figsize']    
figure(figsize=(w,h*.5))

subplot(212)
# Current
#plot(recording.times/ms,recording[0]/nA,'k')
plot(recording.times/ms,current[0]/nA,'k--') # True one
plot(recording.times/ms,I/nA,'k')
xlabel('Time (ms)')
xticks([0,50,100,150,200])
ylabel('I (nA)')
xlim(0,230)
yticks([-1,0,1])
subplot(211)
# Voltage
plot(soma.times/ms,soma[0]/mV-80,'k')
plot(vcmd.times/ms,vcmd[0]/mV-80,'k')
xticks([])
xlim(0,230)
ylabel('Vm (mV)')
ylim(-82,-65)
yticks([-80,-75,-70,-65])
show()

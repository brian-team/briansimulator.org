'''
Bridge compensation.
'''
#import brian_no_units
from brian import *
from brian.library.electrophysiology import *
from fig_params import *

defaultclock.dt=0.01*ms
Re=50*Mohm
Ce=2*ms/Re

El=-70*mV
tau=20*ms
R=50*Mohm

eqs=Equations('''
dv/dt=(El-v+R*Iinj)/tau : volt
I : amp
''')

neuron=NeuronGroup(1,model=eqs+electrode(.5*Re,Ce,v_el='ve',vm='v',i_inj='Iinj',i_cmd='i_el')+\
                   current_clamp('ve','i_el','vr',i_cmd='I',bridge=Re,capa_comp=.9*Ce,Re=.5*Re,Ce=Ce,v_uncomp='v_raw'),
                   implicit=False)
neuron.v=El
neuron.ve=El
neuron.v_raw=El

run(10*ms)
Mv=StateMonitor(neuron,'v',record=0)
MI=StateMonitor(neuron,'I',record=0)
Mve=StateMonitor(neuron,'vr',record=0)
Mvr=StateMonitor(neuron,'v_raw',record=0)

run(10*ms)
neuron.I=.2*nA
run(100*ms)
neuron.I=0*nA
run(100*ms)

new_fig(scale=.5)

subplot(211)
plot(Mv.times/ms,Mv[0]/mV,'k--')
#plot(Mv.times/ms,(Mv[0]+Re*MI[0])/mV)
plot(Mvr.times/ms,Mvr[0]/mV,'k')
ylim(-75,-45)
yticks([-70,-60,-50])
ylabel('V (mV)')
xlim(10,210)
xticks([])
subplot(212)
plot(Mv.times/ms,Mv[0]/mV,'k--')
plot(Mve.times/ms,Mve[0]/mV,'k')
ylim(-75,-45)
yticks([-70,-60,-50])
xlim(10,210)
xlabel('Time (ms)')
ylabel('V (mV)')
show()

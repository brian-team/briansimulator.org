'''
Ideal current-clamp (no electrode)
'''
from brian import *
from brian.library.electrophysiology import *
from fig_params import *

defaultclock.dt=0.01*ms # change to .01*ms for better precision
duration=100*ms
Re=50*Mohm
Ce=.02*ms/Re

El=-70*mV
tau=20*ms
R=50*Mohm

eqs=Equations('''
dv/dt=(El-v+R*Iinj)/tau : volt
I : amp
''')+current_clamp('v','Iinj','vr',i_cmd='I',Re=Re,Ce=Ce)

neuron=NeuronGroup(1,model=eqs,implicit=False)
neuron.v=El

run(100*ms)
Mv=StateMonitor(neuron,'v',record=0)
Mve=StateMonitor(neuron,'vr',record=0)

run(10*ms)
neuron.I=.2*nA
run(100*ms)
neuron.I=0*nA
run(100*ms)

run(duration)

new_fig(scale=.5)

subplot(211)
plot(Mv.times/ms,Mv[0]/mV,'k--')
plot(Mve.times/ms,Mve[0]/mV,'k')
xlim(100,300)
ylim(-75,-45)
xticks([])
yticks([-70,-60,-50])
#xlabel('Time (ms)')
ylabel('V (mV)')
subplot(212)
#plot(Mv.times/ms,(Mve[0]-Mv[0])/mV,'k') # Ue
show()

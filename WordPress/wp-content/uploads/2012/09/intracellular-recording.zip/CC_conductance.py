'''
Conductance estimation in current clamp.

Point model with no active conductances.
The synaptic conductances are identical for all trials,
plus added noise (signal/noise = 2).

Perfect current clamp (no resistance).
'''
from brian import *
from brian.library.electrophysiology import *
from brian.library.random_processes import *
from scipy.stats import linregress
from fig_params import *

rectify=lambda x:clip(x/siemens,0,Inf)*siemens

# Clock
clock_model=Clock(dt=0.01*ms)
clock_recording=Clock(dt=0.1*ms)

# Parameters
Imin=-25*nA
Imax=25*nA
C=200*pF
El=-65*mV
Ee=0*mV
Ei=-75*mV
gl=20*nS
taue=3*ms
taui=7*ms
ge0=20*nS
gi0=50*nS
sigmae=10*nS
sigmai=20*nS
Re=10*Mohm
Ce=.1*ms/Re
duration=150*ms
N=10

# Synaptic conductances
eqs_syn=OrnsteinUhlenbeck('ge',ge0,sigmae,taue)
eqs_syn+=OrnsteinUhlenbeck('gi',gi0,sigmai,taui)
synapses=NeuronGroup(1,model=eqs_syn,clock=clock_model)

# Neuron model and amplifier
eqs=Equations('''
dvm/dt=(gl*(El-vm)+rectify(ge+ge_noise)*(Ee-vm)+rectify(gi+gi_noise)*(Ei-vm)+i_inj)/C:volt
I_cmd:amp
ge:siemens
gi:siemens
i_inj=I_cmd
''')
eqs+=OrnsteinUhlenbeck('ge_noise',0*nS,.5*sigmae,taue) # noise
eqs+=OrnsteinUhlenbeck('gi_noise',0*nS,.5*sigmai,taui) # noise
#eqs+=electrode(.2*Re,Ce,i_cmd='ie')
#eqs+=current_clamp('vm','ie','vr',i_cmd='I_cmd',Re=.8*Re,Ce=Ce,bridge=.95*Re)

# Neuron
neuron=NeuronGroup(N,model=eqs,clock=clock_model)

@network_operation(clock=clock_recording)
def inject_syn(): # inject synaptic current
    neuron.ge=synapses.ge[0]
    neuron.gi=synapses.gi[0]

neuron.vm=El
neuron.ge=ge0
neuron.gi=gi0
neuron.I_cmd=linspace(-.5*nA,.5*nA,N)

run(30*ms)

ge_mon=StateMonitor(neuron,'ge',record=0,clock=clock_recording)
gi_mon=StateMonitor(neuron,'gi',record=0,clock=clock_recording)
v_mon=StateMonitor(neuron,'vm',record=True,clock=clock_recording)

run(duration)

# Linear regression
M=len(v_mon.times)
V=zeros((N,M))
dV=zeros((N,M))
gtot=zeros(M)
Erev=zeros(M)
for i in range(N):
    V[i,:]=v_mon[i]
dV[:,1:-1]=(V[:,2:]-V[:,:-2])/(2*clock_recording.dt)
for j in range(M):
    slope,intercept,_,_,_=linregress(V[:,j],-neuron.I_cmd+C*dV[:,j])
    gtot[j]=-slope
    Erev[j]=-intercept/slope

# Decomposition
ge=(gtot*Erev-gl*El-(gtot-gl)*Ei)/(Ee-Ei)
gi=gtot-ge-gl

new_fig(scale=.5)
subplot(311)
xticks([])
ylabel('Vm (mV)')
yticks([-80,-60,-40])
xlim(30,180)
ylim(-80,-30)
for i in range(N):
    plot(v_mon.times/ms,v_mon[i]/mV,'k')
subplot(312)
xticks([])
xlim(30,180)
yticks([0,25,50])
ylabel('ge (nS)')
#plot(I_mon.times/ms,gtot/nS)
plot(ge_mon.times/ms,rectify(ge_mon[0])/nS,'k--')
plot(v_mon.times/ms,ge/nS,'k')
subplot(313)
plot(gi_mon.times/ms,rectify(gi_mon[0])/nS,'k--')
plot(v_mon.times/ms,gi/nS,'k')
#plot(I_mon.times/ms,Erev/mV)
xlabel('Time ms')
ylabel('gi (nS)')
yticks([0,50,100])
xticks([50,100,150])
xlim(30,180)
show()

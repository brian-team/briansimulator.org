'''
The electrode filters the recording, especially spikes.

Neuron model adapted from Mainen, with noisy input current.
'''
#import brian_no_units
from brian import *
from brian.library.electrophysiology import *
from hhmodel import * # We import the neuron model
from fig_params import *

defaultclock.dt=0.01*ms # change to .01*ms for better precision
duration=300*ms
Re=50*Mohm
Ce=.1*ms/Re

neuron=NeuronGroup(1,model=eqs_hh+electrode(Re,Ce,v_el='ve',vm='v',i_inj='Iinj',i_cmd=0*amp),
                   implicit=True)
neuron.rest()

run(100*ms)
Mv=StateMonitor(neuron,'v',record=0)
Mve=StateMonitor(neuron,'ve',record=0)

run(duration)

new_fig()
subplot(211)
plot(Mv.times/ms,Mv[0]/mV,'k--')
plot(Mve.times/ms,Mve[0]/mV,'k')
#xticks([])
yticks([-100,-50,0,50])
ylabel('V (mV)')
subplot(212)
plot(Mv.times/ms,(Mve[0]-Mv[0])/mV,'k') # Ue
xlabel('Time (ms)')
ylabel('Ue (mV)')
yticks([-100,-50,0,50])
show()

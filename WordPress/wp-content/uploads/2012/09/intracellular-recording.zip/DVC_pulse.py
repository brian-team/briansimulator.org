'''
Discontinuous voltage-clamp
'''
from brian import *
from brian.library.electrophysiology import *
from fig_params import *

defaultclock.dt=.01*ms

taum=20*ms        # membrane time constant
gl=1./(50*Mohm)   # leak conductance
Cm=taum*gl        # membrane capacitance
Re=50*Mohm        # electrode resistance
Ce=0.1*ms/Re      # electrode capacitance

eqs=Equations('''
dvm/dt=(-gl*vm+i_inj)/Cm : volt
I:amp
''')
eqs+=current_clamp(i_cmd='I',Re=Re,Ce=Ce)
setup=NeuronGroup(1,model=eqs)
ampli=SEVC(setup,'v_rec','I',1*kHz,gain=250*nS,gain2=50*nS/ms) # try gain = 500 nS
recording=StateMonitor(ampli,'record',record=True)
soma=StateMonitor(setup,'vm',record=True)

run(5*ms)
ampli.command=20*mV
run(10*ms)
new_fig(scale=0.5)
subplot(212)
plot(recording.times/ms,recording[0]/nA,'k')
xlim(0,15)
xlabel('Time (ms)')
ylabel('I (nA)')
ylim(-6,1)
yticks([-6,-3,0])
subplot(211)
plot(soma.times/ms,soma[0]/mV-70,'k')
xlim(0,15)
ylabel('Vm (mV)')
yticks([-80,-70,-60,-50])
ylim(-80,-45)

show()

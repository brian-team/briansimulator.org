'''
Manual setting of the bridge (current-clamp)
'''
from brian import *
from brian.library.electrophysiology import *
from fig_params import *

defaultclock.dt=.01*ms


taum=20*ms
gl=20*nS
Cm=taum*gl
Re=50*Mohm
Ce=0.3*ms/Re
N=10

eqs=Equations('''
dvm/dt=(-gl*vm+i_inj)/Cm : volt
Rbridge:ohm
I:amp
''')
eqs+=electrode(.6*Re,Ce)
eqs+=current_clamp(vm='v_el',i_inj='i_cmd',i_cmd='I',Re=.4*Re,Ce=Ce,
                   bridge='Rbridge')
setup=NeuronGroup(N,model=eqs)
setup.I=0*nA
setup.v=0*mV
setup.Rbridge[0]=0*ohm
setup.Rbridge[1:]=linspace(40*Mohm,60*Mohm,N-1)
print setup.Rbridge

run(50*ms)
setup.I=.2*nA
run(198*ms)
recording=StateMonitor(setup,'v_rec',record=True)
run(2*ms)
setup.I=0*nA
run(20*ms)
#run(150*ms)

scale=.5
rc('lines',linewidth=2)
rc('font',size=18*scale)
rc('xtick',labelsize=18*scale)
rc('ytick',labelsize=18*scale)
rc('legend',fontsize=18*scale)
rc('axes',labelsize=18*scale,titlesize=18*scale)
fontsize=18*scale
w,h=rcParamsDefault['figure.figsize']    
figure(figsize=(w*scale,h*.75))
#figure()
#new_fig(scale=.5)


subplot(311)
plot(recording.times/second,recording[3]/mV-70,'k')
xlim(.248,.275)
ylim(-65,-45)
yticks([-60,-50])
ylabel('V (mV)')
xticks([])
subplot(312)
plot(recording.times/second,recording[5]/mV-70,'k')
xlim(.248,.275)
ylim(-65,-45)
yticks([-60,-50])
ylabel('V (mV)')
xticks([])
subplot(313)
plot(recording.times/second,recording[7]/mV-70,'k')
xlim(.248,.275)
ylim(-65,-45)
yticks([-60,-50])
ylabel('V (mV)')
xlabel('Time (s)')
show()

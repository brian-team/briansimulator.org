'''
Estimation of electrode resistance using spike shapes.

We find 10% underestimation
'''
from brian import *
from brian.library.electrophysiology import *
from hhmodel import * # We import the neuron model
from scipy import stats

cl=Clock(dt=0.1*ms) # change to .01*ms for better precision
duration=10*second
Re=50*Mohm
Ce=1*ms/Re

neuron=NeuronGroup(1,model=eqs_hh+Equations('Icmd : amp')+\
                   electrode(Re,Ce,v_el='ve',vm='v',i_inj='Iinj',i_cmd='Icmd'),
                   implicit=True,clock=cl)
neuron.rest()

run(100*ms)

@network_operation(Clock(dt=10*ms))
def inject():
    neuron.Icmd=rand()*.5*nA

Mv=StateMonitor(neuron,'v',record=0,clock=cl)
Mve=StateMonitor(neuron,'ve',record=0,clock=cl)
MI=StateMonitor(neuron,'Icmd',record=0,clock=cl)

run(duration,report='text')

# Find spike times
vr=Mve[0]
ind=((vr[1:]>0) & (vr[0:-1]<0)).nonzero()[0]
# Find peak times
ind_peaks=ind.copy()
for i in range(len(ind)):
    ind_peaks[i]+=argmax(vr[ind[i]:ind[i]+50])

slope,intercept,_,_,_=stats.linregress(MI[0][ind_peaks]/nA,Mve[0][ind_peaks]/mV)
print "Estimated resistance:",slope

# Display
scale=.5
rc('lines',linewidth=2)
rc('font',size=18*scale)
rc('xtick',labelsize=18*scale)
rc('ytick',labelsize=18*scale)
rc('legend',fontsize=18*scale)
rc('axes',labelsize=18*scale,titlesize=18*scale)
fontsize=18*scale
w,h=rcParamsDefault['figure.figsize']    
figure(figsize=(w,h*.75))

n=int(1*second/cl.dt)
subplot(311)
plot(Mv.times[:n]/second,Mv[0][:n]/mV,'k--')
plot(Mve.times[:n]/second,Mve[0][:n]/mV,'k')
ylabel('V (mV)')
xlim(0.1,1.1)
xticks([])
yticks([-80,-40,0,40])
subplot(312)
plot(MI.times[:n]/second,MI[0][:n]/nA,'k')
xlim(0.1,1.1)
ylim(-0.1,.6)
ylabel('I (nA)')
xlabel('Time (s)')
subplot(313)
#plot(MI[0]/nA,Mve[0]/mV,'.')
plot(MI[0][ind_peaks]/nA,Mve[0][ind_peaks]/mV,'k.')
plot(MI[0][ind_peaks]/nA,intercept+slope*MI[0][ind_peaks]/nA,'k')
xlabel('I (nA)')
ylabel('Vr (mV)')
yticks([10,20,30,40])
show()

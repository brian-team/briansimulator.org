Supporting code for the Handbook of Neural Activity Measurement.
Romain Brette and Alain Destexhe, eds
Cambridge University Press (2012)

Chapter 3: Intracellular recording

These are scripts for the Brian simulator: http://briansimulator.org

CC_bridge: bridge balance (Fig. 3.4A)
CC_conductance: conductance estimation in current clamp (Fig. 3.10B)
CC_ideal_bridge: ideal bridge balance (Fig. 3.3B)
CC_manual_bridge: bridge balance (Fig. 3.4A)
CC_Re_from_spikes: estimation of electrode resistance using spike shapes (Fig. 3.5)
CC_spike_filtering: spike filtering by electrode capacitance (Fig. 3.3C)
DCC_pulse: DCC example (pulse; Fig. 3.6A)
DCC_Re_change: effect of a change in Re (electrode resistance) in a DCC recording (Fig. 3.6C)
DVC_pulse: discontinuous voltage clamp (Fig. 3.9)
VC_conductance: conductance estimation in voltage clamp (Fig. 3.10A)
VC_offline: offline series compensation (voltage-clamp; Fig. 3.8B)
VC_pulse: voltage-clamp with a step command (Fig. 3.8A)
